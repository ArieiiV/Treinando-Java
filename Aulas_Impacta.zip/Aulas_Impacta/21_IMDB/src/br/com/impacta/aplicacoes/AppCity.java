package br.com.impacta.aplicacoes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AppCity {

	public static void main(String[] args) {

		String url = "jdbc:mysql://localhost:3306/world";
		String usuario = "root";
		String senha = "Imp@ct@";

		try {

			Connection conexao = DriverManager.getConnection(url, usuario, senha);
			System.out.println("Conex�o estabelecida com sucesso...");

			String cmd = "insert into city(name,countryCode,district,population) "
								+ "values (?,?,?,?)";
			
			PreparedStatement ps = conexao.prepareStatement(cmd);
			
			//Inserindo primeira cidade...
			ps.setString(1, "Minha Cidade");
			ps.setString(2, "BRA");
			ps.setString(3, "S�o Paulo");
			ps.setInt(4, 150_000);

			ps.execute();
			
			// inserindo segunda cidade...
			ps.setString(1, "Minha Outra Cidade");
			ps.setString(2, "BRA");
			ps.setString(3, "Rio de Janeiro");
			ps.setInt(4, 250_000);
			
			ps.execute();

			ps.close();

			// Consultando cidades brasileiras com populacao maior que 100_000 habitantes
			String sql = "select * from city where population > ? "
							+ "and CountryCode = ? order by population";
			
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, 100_000);
			ps.setString(2, "BRA");

			ResultSet view = ps.executeQuery();
			while (view.next()) {
				int id = view.getInt("ID");
				String cidade = view.getString("name");
				String pais = view.getString("countryCode");
				String estado = view.getString("district");
				int populacao = view.getInt("population");

				System.out.printf("%d %-30s %-20s %-5s %-10d \n", 
										id, cidade, estado, pais, populacao);
			}

			ps.close();
			conexao.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
