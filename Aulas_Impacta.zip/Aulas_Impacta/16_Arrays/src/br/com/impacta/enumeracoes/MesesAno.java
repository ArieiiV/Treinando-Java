package br.com.impacta.enumeracoes;

public enum MesesAno {
	JANEIRO,
	FEVEREIRO,
	MAR�O,
	ABRIL,
	MAIO,
	JUNHO,
	JULHO,
	AGOSTO,
	SETEMBRO,
	OUTUBRO,
	NOVEMBRO,
	DEZEMBRO
}
