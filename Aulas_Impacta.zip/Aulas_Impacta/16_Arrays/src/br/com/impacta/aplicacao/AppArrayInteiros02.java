package br.com.impacta.aplicacao;

public class AppArrayInteiros02 {
	public static void main(String[] args) {
		int[] numeros = { 20, 16, 7, 38, 5, 4 };
		
		for (int item : numeros) {
			System.out.println(item);
		}
	}
}
