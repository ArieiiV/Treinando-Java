package br.com.impacta.programa;

import javax.swing.JOptionPane;

public class LeituraNumeros {
	public static void main(String[] args) {
		/*
		 * O usu�rio informa v�rios numeros. Apenas os numeros
		 * positivos ser�o mostrados. Se um numero negativo
		 * for informado, o programa o ignorar�.
		 * O programa ser� interrompido apenas se for 
		 * informado o valor 0.
		 */
		
		while(true) {
			int numero = Integer.parseInt(
				JOptionPane.showInputDialog("Informe um numero"));
			if(numero == 0) {
				break;
			}
			if(numero < 0) {
				continue;
			}
			System.out.println(numero);
		}
		System.out.println("----Finalizado----");
	}
}
