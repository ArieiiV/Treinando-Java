package br.com.impacta.programa;

import javax.swing.JOptionPane;

public class AdivinhaNumero {
	public static void main(String[] args) {
		/*
		 * 1. O programa gera um n�mero aleat�rio (0 a 100)
		 * 2. Iterativamente, o usu�rio � solicitado a 
		 *    informar um numero. 
		 * 3. Se o usu�rio informar um valor menor que o 
		 *    numero gerado, o programa dever� responder:
		 *    "Informe um numero maior"
		 * 4. Caso contr�rio, se o usu�rio fornecer um valor 
		 *    acima do numero gerado, o programa dever� responder:
		 *    "Informe um numero menor"
		 * 5. Quando for informado um valor igual ao que o programa
		 *    gerou, o programa deve responder:
		 *    "Voc� acertou em n tentativas"
		 * 
		 */
		
		//gera��o de um numero aleat�rio
		int numero = (int)(Math.random() * 100);
		
		//variavel representando o n� de tentativas
		int tentativas = 0;
		
		//valores m�nimo e m�ximo de tentativas
		int min = 0, max = 100;
		
		while(true) {
			tentativas++;
			
			//obtendo o valor do usu�rio
			int valor = Integer.parseInt(
				JOptionPane.showInputDialog(
					"Informe um numero entre " + min + " e " + max));
			
			//validar o valor informado
			if(valor < min || valor > max) {
				continue;
			}
			
			//se o valor informado for menor que o aleatorio (gerado)...
			if(valor < numero) {
				min = valor + 1;
			} else if (valor > numero) {//se o valor informado for maior...
				max = valor - 1;
			} else {
				break; //aqui, o usu�rio acertou
			}
		}
		JOptionPane.showMessageDialog(null, 
			"Voc� acertou em " + tentativas + " tentativas");
	}
}













