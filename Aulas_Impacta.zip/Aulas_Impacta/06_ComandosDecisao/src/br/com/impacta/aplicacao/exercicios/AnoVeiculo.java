package br.com.impacta.aplicacao.exercicios;

import javax.swing.JOptionPane;

public class AnoVeiculo {
	/*
	 * Escreva um programa que solicite:
	 * - a marca
	 * - o modelo
	 * - o ano
	 * 
	 * de um ve�culo. Se o ano for inferior a 1999, n�o ter�
	 * valor para IPVA.
	 * 
	 * Al�m disso, a marca e o modelo devem ser informados; sen�o o 
	 * usu�rio receber� uma mensagem, e o programa ser� encerrado.
	 * 
	 * Como resposta, mostrar na tela:
	 * 
	 * - a marca
	 * - o modelo
	 * - o ano
	 * - se o IPVA ser� ou n�o pago
	 */
	public static void main(String[] args) {
		
		String marca = JOptionPane.showInputDialog("Marca: ");
		if(marca == null || marca.trim().equals("")) {
			JOptionPane.showMessageDialog(null, "Marca inv�lida");
			return;
		}
		
		String modelo = JOptionPane.showInputDialog("Modelo: ");
		if(modelo == null || modelo.trim().equals("")) {
			JOptionPane.showMessageDialog(null, "Modelo inv�lido");
			return;
		}
		
		int ano = Integer.parseInt(JOptionPane.showInputDialog("Ano: "));
		
		boolean pago = ano <= 1999 ? false : true;
//		if(ano <= 1999) {
//			pago = false;
//		} else {
//			pago = true;
//		}
		
		String resposta = "Marca: " + marca +
							"\nModelo: " + modelo +
							"\nAno: " + ano +
							(pago ? "Paga IPVA" : "N�o paga IPVA");
		JOptionPane.showMessageDialog(null, resposta);

	}
	
}







