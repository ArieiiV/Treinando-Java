package br.com.impacta.classes.exercicios;

public class Curso {
	
	public String descricao;
	public int carga_horaria;
	public double preco;

}
