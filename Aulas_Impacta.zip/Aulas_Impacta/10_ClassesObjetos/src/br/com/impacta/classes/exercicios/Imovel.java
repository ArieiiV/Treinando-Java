package br.com.impacta.classes.exercicios;

public class Imovel {
	public String descricao;
	public double area;
	public String endereco;
	
}
