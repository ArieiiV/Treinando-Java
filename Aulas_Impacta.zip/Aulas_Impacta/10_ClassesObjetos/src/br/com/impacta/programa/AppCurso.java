package br.com.impacta.programa;

import br.com.impacta.classes.exercicios.Curso;

public class AppCurso {
	public static void main(String[] args) {
		
		Curso curso1 = new Curso();
		curso1.descricao = "Java Programmer";
		curso1.carga_horaria = 100;
		curso1.preco = 1200.50;
		
		Curso curso2 = new Curso();
		curso2.descricao = "Desenvolvimento Web";
		curso2.carga_horaria = 60;
		curso2.preco = 850;
		
		System.out.println("curso 1");
		System.out.println("Descri��o: " + curso1.descricao);
		System.out.println("Carga Hor�ria: " + curso1.carga_horaria);
		System.out.println("Pre�o: " + curso1.preco);
		System.out.println("---------------------------");
		
		System.out.println("curso 2");
		System.out.println("Descri��o: " + curso2.descricao);
		System.out.println("Carga Hor�ria: " + curso2.carga_horaria);
		System.out.println("Pre�o: " + curso2.preco);
		System.out.println("---------------------------");		
	}
}
