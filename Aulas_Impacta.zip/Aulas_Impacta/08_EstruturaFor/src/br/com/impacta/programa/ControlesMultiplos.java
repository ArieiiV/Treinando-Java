package br.com.impacta.programa;

public class ControlesMultiplos {
	public static void main(String[] args) {
		for (int i = 0, j = 20; i < j; i += 1, j -= 2) {
			System.out.println("i=" + i + ", j=" + j);
		}
	}
}
