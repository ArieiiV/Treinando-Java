
public class SegundoPrograma {
	public static void main(String[] args) {
		System.out.println("Exemplo de teclas de atalho");
	}
}
