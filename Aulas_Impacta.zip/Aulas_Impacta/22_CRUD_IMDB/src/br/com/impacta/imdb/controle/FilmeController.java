package br.com.impacta.imdb.controle;

import java.util.List;

import br.com.impacta.imdb.modelo.Filme;
import br.com.impacta.imdb.persistencia.DAOFilme;

public class FilmeController {
	
	public void inserir(Filme filme) throws Exception {
		DAOFilme dao = new DAOFilme();
		dao.inserir(filme);
	}
	
	public void remover(Filme filme) throws Exception {
		DAOFilme dao = new DAOFilme();
		dao.remover(filme);
	}
	
	public void alterar(Filme filme) throws Exception {
		DAOFilme dao = new DAOFilme();
		dao.alterar(filme);

	}
	
	public List<Filme> listar() throws Exception{
		List<Filme> filmes = null;
		
		DAOFilme dao = new DAOFilme();
		filmes = dao.getAll();
		
		return filmes;
	}

}
