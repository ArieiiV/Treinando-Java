package br.com.impacta.enumeracoes;

public enum DiasSemana {
	DOMINGO, 
	SEGUNDA, 
	TER�A, 
	QUARTA, 
	QUINTA, 
	SEXTA, 
	SABADO
}
