package br.com.impacta.enumeracoes;

public enum Sexos {
	MASCULINO, FEMININO, OUTROS
}
