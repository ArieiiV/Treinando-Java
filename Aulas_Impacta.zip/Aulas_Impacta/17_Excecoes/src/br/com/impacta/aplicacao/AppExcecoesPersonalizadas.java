package br.com.impacta.aplicacao;

import javax.swing.JOptionPane;
import javax.swing.UIManager;

import br.com.impacta.classes.Funcionario;
import br.com.impacta.enumeracoes.Sexo;

public class AppExcecoesPersonalizadas {
	public static void main(String[] args) {
		
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			
			Funcionario funcionario = new Funcionario(
					Sexo.FEMININO, 60, 1.65);
			funcionario.setCpf("12345678900");
			funcionario.setSalario(1800);
			
			JOptionPane.showMessageDialog(null, funcionario.exibir());
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(
					null, 
					e.getMessage(), 
					"Erro", 
					JOptionPane.ERROR_MESSAGE);
		}
	}
}
