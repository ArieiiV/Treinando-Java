package br.com.impacta.aplicacao;

import javax.swing.JOptionPane;

public class AppExcecoes02 {
	/*
	 * Usando o bloco try com multiplos blocos catch()
	 */
	public static void main(String[] args) {
		try {
			String nome = JOptionPane.showInputDialog("Seu nome: ");
			System.out.println("Nome: " + nome.toUpperCase());
				
			int idade = Integer.parseInt(
				JOptionPane.showInputDialog("Sua idade"));		
			System.out.println("Idade: " + idade);
		
		} catch(NumberFormatException e) {
			JOptionPane.showMessageDialog(null, "Erro: " + e.getMessage());
		} catch(NullPointerException e) {
			JOptionPane.showMessageDialog(null, "Erro: " + e.getMessage());
		}
	}
}







