package br.com.impacta.interfaces;

@FunctionalInterface
public interface Processo01 {
	double processar();
}
