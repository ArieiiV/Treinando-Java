package br.com.impacta.interfaces;

@FunctionalInterface
public interface Operacao {
	double calcular(double a, double b);
}
