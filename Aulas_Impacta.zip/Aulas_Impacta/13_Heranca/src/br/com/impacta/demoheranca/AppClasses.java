package br.com.impacta.demoheranca;

public class AppClasses {
	public static void main(String[] args) {
		new Classe3();
	}
}
