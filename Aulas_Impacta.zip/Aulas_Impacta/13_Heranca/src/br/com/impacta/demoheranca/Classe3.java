package br.com.impacta.demoheranca;

public class Classe3 extends Classe2 {
	public Classe3() {
		super();
		System.out.println("Estamos na classe 3");
	}
}
